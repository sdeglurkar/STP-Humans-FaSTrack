from . import hardmax
from . import softmax
