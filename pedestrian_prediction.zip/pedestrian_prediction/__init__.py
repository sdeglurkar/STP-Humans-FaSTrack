print("init for pedestrian prediction")
